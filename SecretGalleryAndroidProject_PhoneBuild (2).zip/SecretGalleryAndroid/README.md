# Secret Gallery Android app

This is an Android app wrapping Secret Gallery Maker in a WebView. It supports selecting cover/reveal images, adding pairs, and saving generated HTML galleries to Downloads.

## Build without a PC (using GitHub Actions)

1. On your phone, sign in to GitHub and create a **public or private repository** (for example `SecretGallery`).
2. Extract this ZIP on your phone using your file manager or an archive app.
3. Upload the **contents** of the `SecretGalleryAndroid` folder to the repository's root, including the hidden `.github/workflows/build-apk.yml` file. Make sure `.github/workflows/build-apk.yml` exists in the repo; the workflow file may need to be uploaded separately if your file picker hides dot-folders.
4. Open the repository's **Actions** tab. Choose **Build Secret Gallery APK** and tap **Run workflow** (or wait for the first push workflow to run).
5. When the run finishes successfully, open that run and download the `SecretGallery-debug-apk` artifact.
6. Extract the artifact ZIP on your phone. Tap `app-debug.apk` to install. If Android asks, allow your browser/file manager to install unknown apps.

The APK is a debug-signed installable build for personal testing, not a Play Store release. Keep your repository private if you do not want to share the app source. GitHub account and Actions availability/usage limits apply.

## Build with Android Studio

Open this folder in Android Studio and run `assembleDebug`. The APK is generated at `app/build/outputs/apk/debug/app-debug.apk`.

## Notes

- Generated gallery files are saved as HTML in Downloads and can be opened in a browser.
- Photo pairs are embedded into generated HTML; large photos make files larger.
